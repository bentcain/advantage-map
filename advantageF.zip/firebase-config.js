const firebaseConfig = {
  apiKey: "AIzaSyD7JkobzpJcrOHU_fNwXuEQqdYL1iAiiRQ",
  authDomain: "parcel-notes-system.firebaseapp.com",
  databaseURL: "https://parcel-notes-system-default-rtdb.firebaseio.com",
  projectId: "parcel-notes-system",
  storageBucket: "parcel-notes-system.appspot.com",
  messagingSenderId: "538142262863",
  appId: "1:538142262863:web:89dfd4cf60bb2dc4694c3a",
  measurementId: "G-GQ3CQ9EKPH"
};
